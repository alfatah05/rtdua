import { api } from '../api/http.js'
import { USE_MOCK } from '../config/dataSource.js'

export async function listPengumuman({ beranda = false } = {}) {
  if (USE_MOCK.konten) return { ok: true, data: [] }
  try {
    const res = await api('/pengumuman' + (beranda ? '?beranda=1' : ''))
    return { ok: true, data: res.data }
  } catch (e) {
    return { ok: false, error: e.message }
  }
}
export async function detailPengumuman(id) {
  if (USE_MOCK.konten) return { ok: false, error: 'mock' }
  try {
    const res = await api('/pengumuman/' + id)
    return { ok: true, data: res.data }
  } catch (e) {
    return { ok: false, error: e.message }
  }
}
export async function buatPengumuman(payload) {
  try {
    const res = await api('/pengumuman', { method: 'POST', body: payload })
    return { ok: true, data: res.data }
  } catch (e) {
    return { ok: false, error: e.message }
  }
}
export async function ubahPengumuman(id, payload) {
  try {
    const res = await api('/pengumuman/' + id, { method: 'PUT', body: payload })
    return { ok: true, data: res.data }
  } catch (e) {
    return { ok: false, error: e.message }
  }
}
export async function hapusPengumuman(id) {
  try {
    await api('/pengumuman/' + id, { method: 'DELETE' })
    return { ok: true }
  } catch (e) {
    return { ok: false, error: e.message }
  }
}

export async function listProgram() {
  if (USE_MOCK.konten) return { ok: true, data: [] }
  try {
    const res = await api('/program')
    return { ok: true, data: res.data }
  } catch (e) {
    return { ok: false, error: e.message }
  }
}
export async function detailProgram(id) {
  try {
    const res = await api('/program/' + id)
    return { ok: true, data: res.data }
  } catch (e) {
    return { ok: false, error: e.message }
  }
}
export async function buatProgram(payload) {
  try {
    const res = await api('/program', { method: 'POST', body: payload })
    return { ok: true, data: res.data }
  } catch (e) {
    return { ok: false, error: e.message }
  }
}
export async function ubahProgram(id, payload) {
  try {
    const res = await api('/program/' + id, { method: 'PUT', body: payload })
    return { ok: true, data: res.data }
  } catch (e) {
    return { ok: false, error: e.message }
  }
}
export async function hapusProgram(id) {
  try {
    await api('/program/' + id, { method: 'DELETE' })
    return { ok: true }
  } catch (e) {
    return { ok: false, error: e.message }
  }
}

export async function listAlbum() {
  if (USE_MOCK.konten) return { ok: true, data: [] }
  try {
    const res = await api('/galeri')
    return { ok: true, data: res.data }
  } catch (e) {
    return { ok: false, error: e.message }
  }
}
export async function detailAlbum(id) {
  try {
    const res = await api('/galeri/' + id)
    return { ok: true, data: res.data }
  } catch (e) {
    return { ok: false, error: e.message }
  }
}
export async function buatAlbum(payload) {
  try {
    const res = await api('/galeri', { method: 'POST', body: payload })
    return { ok: true, data: res.data }
  } catch (e) {
    return { ok: false, error: e.message }
  }
}
export async function hapusAlbum(id) {
  try {
    await api('/galeri/' + id, { method: 'DELETE' })
    return { ok: true }
  } catch (e) {
    return { ok: false, error: e.message }
  }
}
export async function tambahFoto(albumId, payload) {
  try {
    const res = await api('/galeri/' + albumId + '/foto', { method: 'POST', body: payload })
    return { ok: true, data: res.data }
  } catch (e) {
    return { ok: false, error: e.message }
  }
}
export async function hapusFoto(ids) {
  try {
    const res = await api('/galeri/foto/hapus', { method: 'POST', body: { ids } })
    return { ok: true, data: res.data }
  } catch (e) {
    return { ok: false, error: e.message }
  }
}

// ---- Kader konten (posyandu / pengajian / lingkungan) ----
export async function listKaderKonten(kategori) {
  if (USE_MOCK.konten) return { ok: true, data: [] }
  try {
    const q = kategori ? ('?kategori=' + encodeURIComponent(kategori)) : ''
    const res = await api('/kader-konten' + q)
    return { ok: true, data: res.data }
  } catch (e) {
    return { ok: false, error: e.message }
  }
}
export async function detailKaderKonten(id) {
  try {
    const res = await api('/kader-konten/' + id)
    return { ok: true, data: res.data }
  } catch (e) {
    return { ok: false, error: e.message }
  }
}
export async function buatKaderKonten(payload) {
  try {
    const res = await api('/kader-konten', { method: 'POST', body: payload })
    return { ok: true, data: res.data }
  } catch (e) {
    return { ok: false, error: e.message }
  }
}
export async function ubahKaderKonten(id, payload) {
  try {
    const res = await api('/kader-konten/' + id, { method: 'PUT', body: payload })
    return { ok: true, data: res.data }
  } catch (e) {
    return { ok: false, error: e.message }
  }
}
export async function hapusKaderKonten(id) {
  try {
    await api('/kader-konten/' + id, { method: 'DELETE' })
    return { ok: true }
  } catch (e) {
    return { ok: false, error: e.message }
  }
}

// ---- Bazis ----
export async function getBazis() {
  if (USE_MOCK.konten) {
    return {
      ok: true,
      data: {
        label_bulan: 'Bazis',
        items: [
          { rt: 'RT 001', total: 0 }, { rt: 'RT 002', total: 0 },
          { rt: 'RT 003', total: 0 }, { rt: 'RT 004', total: 0 },
          { rt: 'RT 005', total: 0 }, { rt: 'RT 006', total: 0 },
          { rt: 'RT 007', total: 0 }, { rt: 'RT 008', total: 0 },
        ],
      },
    }
  }
  try {
    const res = await api('/bazis')
    return { ok: true, data: res.data }
  } catch (e) {
    return { ok: false, error: e.message }
  }
}
export async function simpanBazis(payload) {
  try {
    const res = await api('/bazis', { method: 'PUT', body: payload })
    return { ok: true, data: res.data }
  } catch (e) {
    return { ok: false, error: e.message }
  }
}
