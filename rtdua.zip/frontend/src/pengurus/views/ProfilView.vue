<template>
  <div>
    <AppBackHeader title="Profil" />

    <div class="flex flex-col items-center text-center mb-6 pt-2">
      <button
        type="button"
        class="relative w-24 h-24 mb-3 active:scale-95 transition-transform disabled:opacity-70"
        aria-label="Ubah foto profil"
        :disabled="uploadingFoto"
        @click="pickFoto"
      >
        <span
          class="absolute inset-0 rounded-full bg-[var(--gd)] text-[var(--gm)] grid place-items-center text-3xl font-bold overflow-hidden"
        >
          <img v-if="fotoUrl" :src="fotoUrl" alt="Foto profil" class="w-full h-full object-cover" />
          <span v-else>{{ inisial }}</span>
        </span>
        <span
          class="absolute -bottom-0.5 -right-0.5 w-8 h-8 rounded-full bg-[var(--g)] text-white grid place-items-center border-2 border-[var(--bg)] z-10 shadow-sm"
        >
          <Camera :size="14" />
        </span>
      </button>
      <input ref="fileInput" type="file" accept="image/*" class="hidden" @change="onFoto" />
      <p class="text-xl font-extrabold m-0">{{ user?.nama || 'Pengurus' }}</p>
      <p class="text-[13px] text-[var(--mut)] m-0 mt-0.5">{{ user?.jabatan || user?.role || '—' }}</p>
      <p class="text-[13px] text-[var(--mut)] m-0">@{{ user?.username || '—' }}</p>
      <p v-if="uploadingFoto" class="text-[12px] text-[var(--mut)] m-0 mt-1">Mengunggah foto…</p>
    </div>

    <div class="px-1 space-y-0.5">
      <button
        v-for="m in menus"
        :key="m.label"
        type="button"
        class="w-full flex flex-row items-center gap-3 px-2 py-3.5 text-left active:scale-[0.99] transition-transform"
        @click="m.action ? m.action() : $router.push(m.to)"
      >
        <span class="w-10 h-10 rounded-full grid place-items-center shrink-0" :style="{ background: m.bg, color: m.color }">
          <component :is="m.icon" :size="18" />
        </span>
        <div class="flex-1 min-w-0">
          <p class="font-semibold text-[15px] m-0">{{ m.label }}</p>
          <p v-if="m.desc" class="text-[12px] text-[var(--mut)] m-0">{{ m.desc }}</p>
        </div>
        <span v-if="m.right" class="text-[13px] text-[var(--mut)] shrink-0">{{ m.right }}</span>
        <ChevronRight v-else :size="18" class="text-[var(--mut)] shrink-0" />
      </button>
    </div>

    <button
      type="button"
      class="w-full min-h-[48px] mt-8 rounded-full bg-[var(--card2)] font-bold active:scale-[0.98] transition-transform"
      @click="doLogout"
    >
      Keluar
    </button>

    <p class="text-center text-[12px] text-[var(--mut)] mt-6 mb-2">rtdua · versi 0.1.0</p>

    <div
      v-if="showNama"
      class="fixed inset-0 z-50 flex items-end justify-center bg-black/40"
      @click.self="showNama = false"
    >
      <div class="w-full max-w-[560px] rounded-t-[24px] bg-[var(--bg)] p-5 pb-[calc(20px+env(safe-area-inset-bottom,0px))]">
        <h2 class="text-[17px] font-extrabold m-0 mb-1">Ubah nama tampilan</h2>
        <p class="text-[12px] text-[var(--mut)] m-0 mb-4">Username login tidak berubah ({{ user?.username }}).</p>
        <label class="block text-[13px] font-semibold text-[var(--mut)] mb-1">Nama</label>
        <input
          v-model="namaForm"
          type="text"
          class="w-full min-h-12 px-4 rounded-full bg-[var(--search)] border-0 outline-none text-[15px] mb-3"
          placeholder="Nama lengkap"
        />
        <p v-if="namaErr" class="text-[13px] text-red-600 text-center mb-2">{{ namaErr }}</p>
        <button
          type="button"
          class="w-full min-h-12 rounded-full font-bold text-white bg-[var(--g)] disabled:opacity-60"
          :disabled="namaSaving"
          @click="simpanNama"
        >
          {{ namaSaving ? 'Menyimpan…' : 'Simpan' }}
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, ref } from 'vue'
import { useRouter } from 'vue-router'
import {
  Camera, ChevronRight, KeyRound, Moon, Settings, Users, Info, UserRound
} from 'lucide-vue-next'
import AppBackHeader from '@shared/components/AppBackHeader.vue'
import { useAuth } from '@shared/composables/useAuth.js'
import { useTheme } from '@shared/composables/useTheme.js'
import { useToast } from '@shared/composables/useToast.js'
import { api } from '@shared/api/http.js'
import { updateFotoProfil } from '@shared/services/auth.js'
import { uploadGambar, mediaUrl } from '@shared/services/upload.js'

const router = useRouter()
const { user, logout, isKetua, ensureSession } = useAuth()
const { mode, toggle } = useTheme()
const { show } = useToast()

const fileInput = ref(null)
const uploadingFoto = ref(false)
const localFoto = ref('')

const showNama = ref(false)
const namaForm = ref('')
const namaErr = ref('')
const namaSaving = ref(false)

const inisial = computed(() => {
  const n = user.value?.nama || 'P'
  return n.split(/\s+/).map(w => w[0]).slice(0, 2).join('').toUpperCase()
})

const fotoUrl = computed(() => {
  if (localFoto.value) return localFoto.value
  const f = user.value?.foto
  return f ? mediaUrl(f) : ''
})

const menus = computed(() => {
  const list = [
    {
      label: 'Ubah nama',
      desc: 'Nama tampilan di profil & struktur',
      icon: UserRound,
      action: () => {
        namaForm.value = user.value?.nama || ''
        namaErr.value = ''
        showNama.value = true
      },
      bg: 'rgba(16,185,129,.18)',
      color: '#059669',
    },
    {
      label: 'Ganti password',
      desc: 'Ubah kata sandi masuk',
      icon: KeyRound,
      action: () => show('Ganti password menyusul'),
      bg: 'rgba(16,185,129,.18)',
      color: '#059669',
    },
    {
      label: 'Mode gelap',
      desc: mode.value === 'dark' ? 'Sedang aktif' : 'Nonaktif',
      icon: Moon,
      action: () => toggle(),
      right: mode.value === 'dark' ? 'Aktif' : 'Off',
      bg: 'rgba(107,114,128,.18)',
      color: '#4B5563',
    },
  ]
  if (isKetua.value) {
    list.push(
      {
        label: 'Pengaturan aplikasi',
        desc: 'Nama RT, blok, akses warga',
        icon: Settings,
        to: '/pengaturan-aplikasi',
        bg: 'rgba(59,130,246,.18)',
        color: '#2563EB',
      },
      {
        label: 'Kelola pengurus',
        desc: 'Angkat / lepas pengurus',
        icon: Users,
        to: '/kelola-pengurus',
        bg: 'rgba(6,182,212,.18)',
        color: '#0891B2',
      },
    )
  }
  list.push({
    label: 'Tentang aplikasi',
    desc: 'rtdua untuk pengurus RT',
    icon: Info,
    action: () => show('rtdua v0.1.0'),
    bg: 'rgba(168,85,247,.18)',
    color: '#7C3AED',
  })
  return list
})

function pickFoto() {
  if (uploadingFoto.value) return
  fileInput.value?.click()
}

async function onFoto(e) {
  const f = e.target.files?.[0]
  e.target.value = ''
  if (!f) return
  uploadingFoto.value = true
  const up = await uploadGambar(f, 'foto_profil', { maxSide: 800 })
  if (!up.ok) {
    uploadingFoto.value = false
    show(up.error || 'Upload gagal')
    return
  }
  const res = await updateFotoProfil(up.data.path)
  uploadingFoto.value = false
  if (!res.ok) {
    show(res.error || 'Gagal menyimpan foto')
    return
  }
  const updated = res.user || {}
  if (user.value) {
    Object.assign(user.value, updated)
    try {
      localStorage.setItem('rtdua-auth-pengurus', JSON.stringify(user.value))
    } catch (err) {}
  }
  localFoto.value = updated.foto ? mediaUrl(updated.foto) : mediaUrl(up.data.path)
  show('Foto profil diperbarui')
}

async function simpanNama() {
  namaErr.value = ''
  const n = String(namaForm.value || '').trim()
  if (!n) {
    namaErr.value = 'Nama wajib diisi'
    return
  }
  namaSaving.value = true
  try {
    await api('/auth/profil', { method: 'PUT', body: { nama: n } })
    showNama.value = false
    show('Nama disimpan')
    await ensureSession('pengurus')
  } catch (e) {
    namaErr.value = e.message || 'Gagal menyimpan'
  } finally {
    namaSaving.value = false
  }
}

function doLogout() {
  logout('pengurus')
  router.replace('/login')
}
</script>
