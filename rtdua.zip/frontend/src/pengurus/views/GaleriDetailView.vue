<template>
  <div>
    <AppBackHeader :title="album?.judul || 'Album'" />
    <AppPageSpinner v-if="loading" />
    <p v-else-if="err" class="text-[13px] text-red-600 text-center py-4">{{ err }}</p>
    <template v-else>
      <p class="text-[13px] text-[var(--mut)] mb-3">{{ album?.tanggal_kegiatan || '—' }} · {{ (album?.foto || []).length }} foto</p>
      <label class="block w-full min-h-[48px] rounded-full bg-[var(--g)] text-white font-bold grid place-items-center cursor-pointer mb-4">
        {{ uploading ? 'Mengunggah…' : 'Tambah foto' }}
        <input type="file" accept="image/*" multiple class="hidden" :disabled="uploading" @change="onFiles" />
      </label>
      <p v-if="progress" class="text-[13px] text-[var(--mut)] mb-2">{{ progress }}</p>

      <!-- Masonry 2 kolom: rasio asli landscape / portrait -->
      <div v-if="(album?.foto || []).length" class="galeri-masonry">
        <div
          v-for="f in album.foto"
          :key="f.id"
          class="galeri-masonry-item relative rounded-[12px] overflow-hidden bg-[var(--search)]"
        >
          <img
            :src="mediaUrl(f.thumb || f.file)"
            class="block w-full h-auto"
            alt=""
            loading="lazy"
          />
          <button
            type="button"
            class="absolute top-1.5 right-1.5 w-8 h-8 rounded-full bg-black/55 text-white text-sm font-bold grid place-items-center"
            aria-label="Hapus foto"
            @click="hapus(f.id)"
          >×</button>
        </div>
      </div>
      <p v-else class="text-[13px] text-[var(--mut)] text-center py-8">Belum ada foto</p>

      <button type="button" class="w-full min-h-[44px] mt-6 rounded-full bg-red-50 text-red-600 font-semibold" @click="hapusAlbum">Hapus album</button>
      <p v-if="msg" class="text-[13px] text-center mt-2" :class="msgOk ? 'text-[var(--g)]' : 'text-red-600'">{{ msg }}</p>
    </template>
  </div>
</template>

<style scoped>
/* Pinterest / bento: 2 kolom, tinggi mengikuti rasio gambar */
.galeri-masonry {
  column-count: 2;
  column-gap: 8px;
}
.galeri-masonry-item {
  break-inside: avoid;
  -webkit-column-break-inside: avoid;
  page-break-inside: avoid;
  margin-bottom: 8px;
}
.galeri-masonry-item img {
  vertical-align: top;
}
</style>

<script setup>
import AppPageSpinner from '@shared/components/AppPageSpinner.vue'

import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import AppBackHeader from '@shared/components/AppBackHeader.vue'
import { detailAlbum, tambahFoto, hapusFoto, hapusAlbum as delAlbum } from '@shared/services/konten.js'
import { uploadGambar, mediaUrl } from '@shared/services/upload.js'
import { waitImages, takeImageUrls } from '@shared/utils/waitImages.js'

const route = useRoute()
const router = useRouter()
const album = ref(null)
const loading = ref(true)
const err = ref('')
const uploading = ref(false)
const progress = ref('')
const msg = ref('')
const msgOk = ref(true)

async function load() {
  loading.value = true
  const res = await detailAlbum(route.params.id)
  if (!res.ok) {
    err.value = res.error || 'Gagal'
    loading.value = false
    return
  }
  album.value = res.data
  const fotos = album.value?.foto || []
  await waitImages(
    takeImageUrls(
      fotos.slice(0, 4).map((f) => mediaUrl(f.thumb || f.file)),
      4
    )
  )
  loading.value = false
}

async function onFiles(e) {
  const files = Array.from(e.target.files || [])
  e.target.value = ''
  if (!files.length) return
  uploading.value = true
  let ok = 0
  for (let i = 0; i < files.length; i++) {
    progress.value = `Upload ${i + 1}/${files.length}`
    const up = await uploadGambar(files[i], 'galeri', { maxSide: 2000, withThumb: true })
    if (!up.ok) continue
    const res = await tambahFoto(route.params.id, {
      file: up.data.path,
      thumb: up.data.thumb || null,
    })
    if (res.ok) ok++
  }
  uploading.value = false
  progress.value = ''
  msgOk.value = true
  msg.value = `${ok} foto ditambah`
  await load()
}

async function hapus(id) {
  if (!confirm('Hapus foto ini?')) return
  await hapusFoto([id])
  await load()
}

async function hapusAlbum() {
  if (!confirm('Hapus album beserta semua foto?')) return
  const res = await delAlbum(route.params.id)
  if (res.ok) router.replace('/konten/galeri')
  else { msgOk.value = false; msg.value = res.error || 'Gagal' }
}

onMounted(load)
</script>
